# Desert Plane Game

Jogo exemplo em Python + Pygame com:
- Fundo desértico rolando (parallax scrolling)
- Avião jogável com hélice animada
- Personagem alternativo (TAB alterna)
- Itens coletáveis: Banana (BananaPro), Engrenagem (Gear), Hélice (PropellerPart), Parafuso (Bolt)
- Efeito de faísca ao coletar
- HUD com contadores

## Como rodar

1. Instale dependências:
```bash
pip install -r requirements.txt
```
2. Execute:
```bash
python3 main.py
```

## Controles
- **Setas** ou **WASD**: mover
- **TAB**: alternar entre Avião e Boneco
- **ESC**: sair (ou feche a janela)

Sem imagens externas — tudo é desenhado via Pygame.
