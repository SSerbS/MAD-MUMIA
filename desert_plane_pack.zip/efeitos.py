
import pygame

effects_group = pygame.sprite.Group()

def coletar_itens(player, itens_group):
    hits = pygame.sprite.spritecollide(player, itens_group, False)
    got = []
    for it in hits:
        if hasattr(it, "collect"):
            it.collect(effects_group)
        else:
            it.kill()
        got.append(it)
    return got

def atualizar_e_desenhar(screen):
    effects_group.update()
    effects_group.draw(screen)
