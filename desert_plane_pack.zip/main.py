
import pygame, random, math
from coletaveis import BananaPro, Gear, PropellerPart, Bolt
from efeitos import effects_group, coletar_itens, atualizar_e_desenhar
from player import AirplanePlayer, BonecoPlayer

WIDTH, HEIGHT = 960, 540
FPS = 60

class Desert:
    def __init__(self, size):
        self.w, self.h = size
        self.layer_far = self._make_far()
        self.layer_mid = self._make_mid()
        self.layer_near = self._make_near()
        self.x_far = 0; self.x_mid = 0; self.x_near = 0

    def _sky(self, surf):
        for y in range(self.h):
            a = y/max(1,self.h-1)
            col = (int(240*(1-a)+255*a), int(210*(1-a)+230*a), int(160*(1-a)+190*a))
            pygame.draw.line(surf, col, (0,y), (self.w,y))

    def _make_far(self):
        surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA).convert_alpha()
        self._sky(surf)
        base_y = int(self.h*0.65)
        for i in range(3):
            color = (225-10*i, 200-8*i, 150-6*i, 180)
            points = []
            for x in range(0, self.w, 8):
                y = base_y - 20*i + int(14*math.sin(0.006*x + i))
                points.append((x,y))
            points += [(self.w, self.h), (0, self.h)]
            pygame.draw.polygon(surf, color, points)
        return surf

    def _make_mid(self):
        surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA).convert_alpha()
        base_y = int(self.h*0.72)
        for i in range(2):
            color = (230, 190-10*i, 120-6*i, 200)
            points = []
            for x in range(0, self.w, 6):
                y = base_y - 12*i + int(18*math.sin(0.01*x + i))
                points.append((x,y))
            points += [(self.w, self.h), (0, self.h)]
            pygame.draw.polygon(surf, color, points)
        for _ in range(6):
            x = random.randint(0, self.w-20)
            self._draw_cactus(surf, x, base_y-10)
        return surf

    def _make_near(self):
        surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA).convert_alpha()
        base_y = int(self.h*0.82)
        color = (235, 185, 110, 255)
        points = []
        for x in range(0, self.w, 4):
            y = base_y + int(10*math.sin(0.02*x))
            points.append((x,y))
        points += [(self.w, self.h), (0, self.h)]
        pygame.draw.polygon(surf, color, points)
        return surf

    def _draw_cactus(self, surf, x, ground_y):
        h = random.randint(40,70)
        pygame.draw.rect(surf, (40,120,60), (x, ground_y-h, 10, h))
        pygame.draw.rect(surf, (40,120,60), (x-8, ground_y-h+20, 8, 16))
        pygame.draw.rect(surf, (40,120,60), (x+10, ground_y-h+10, 8, 16))

    def update(self, dt, speed=160):
        self.x_far = (self.x_far - speed*0.2*dt) % self.w
        self.x_mid = (self.x_mid - speed*0.5*dt) % self.w
        self.x_near = (self.x_near - speed*1.0*dt) % self.w

    def draw(self, screen):
        for x in (-self.x_far, self.w - self.x_far):
            screen.blit(self.layer_far, (x,0))
        for x in (-self.x_mid, self.w - self.x_mid):
            screen.blit(self.layer_mid, (x,0))
        for x in (-self.x_near, self.w - self.x_near):
            screen.blit(self.layer_near, (x,0))

class Spawner:
    def __init__(self, group):
        self.group = group
        self.timer = 0.0
        self.interval = 1.0

    def spawn(self):
        y = random.randint(80, HEIGHT-100)
        x = WIDTH + 40
        choice = random.choice([BananaPro, Gear, PropellerPart, Bolt])
        self.group.add(choice(x,y))

    def update(self, dt):
        self.timer += dt
        if self.timer >= self.interval:
            self.timer = 0.0
            self.spawn()

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Desert Plane — collectibles + sparkle")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 22)

    from coletaveis import BananaPro, Gear, PropellerPart, Bolt
    from efeitos import effects_group, coletar_itens, atualizar_e_desenhar
    from player import AirplanePlayer, BonecoPlayer

    desert = Desert((WIDTH, HEIGHT))

    plane = AirplanePlayer((WIDTH//3, HEIGHT//2))
    hero = BonecoPlayer((WIDTH//3, int(HEIGHT*0.78)))
    active_player = plane
    all_sprites = pygame.sprite.Group(active_player)

    items = pygame.sprite.Group()
    spawner = Spawner(items)

    life = 3; ammo = 0; parts = 0; bananas = 0

    running = True
    while running:
        dt = clock.tick(FPS)/1000.0
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_TAB:
                    all_sprites.remove(active_player)
                    if active_player is plane:
                        active_player = hero
                    else:
                        active_player = plane
                    active_player.rect.centerx = WIDTH//3
                    all_sprites.add(active_player)

        keys = pygame.key.get_pressed()

        desert.update(dt, speed=160)
        spawner.update(dt)
        for it in items:
            it.rect.centerx -= int(160*dt)
            if it.rect.right < -10:
                it.kill()

        active_player.update(dt, keys)
        items.update()

        got = coletar_itens(active_player, items)
        for it in got:
            if isinstance(it, BananaPro):
                bananas += 1; life = min(9, life+1)
            elif isinstance(it, (Gear, PropellerPart, Bolt)):
                parts += 1; ammo += 2

        desert.draw(screen)
        items.draw(screen)
        all_sprites.draw(screen)

        hud = f"Vida: {life}   Munição: {ammo}   Peças: {parts}   Bananas: {bananas}   Player: {'Avião' if active_player is plane else 'Boneco'} (TAB troca)"
        screen.blit(font.render(hud, True, (20,20,20)), (12, 10))
        screen.blit(font.render(hud, True, (250,250,250)), (13, 9))

        atualizar_e_desenhar(screen)

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
