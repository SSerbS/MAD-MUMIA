
import pygame, math, random

class SparkleEffect(pygame.sprite.Sprite):
    def __init__(self, pos, size=28, frames=8, fps=22):
        super().__init__()
        self.frames = self._make_frames(size, frames)
        self.index = 0
        self.image = self.frames[self.index]
        self.rect = self.image.get_rect(center=pos)
        self._last = pygame.time.get_ticks()
        self._ft = int(1000/max(1,fps))

    def _make_frames(self, size, frames):
        imgs = []
        cx, cy = size//2, size//2
        for i in range(frames):
            surf = pygame.Surface((size, size), pygame.SRCALPHA)
            t = (i+1)/frames
            r = int(2 + t*(size//2))
            alpha = int(255*(1-t))
            for ang in range(0,360,30):
                rad = math.radians(ang)
                x = cx + int(r*math.cos(rad))
                y = cy + int(r*math.sin(rad))
                pygame.draw.circle(surf, (255,230,120,alpha), (x,y), 2)
            pygame.draw.circle(surf, (255,255,255,alpha), (cx,cy), 2)
            imgs.append(surf)
        return imgs

    def update(self):
        now = pygame.time.get_ticks()
        if now - self._last >= self._ft:
            self._last = now
            self.index += 1
            if self.index >= len(self.frames):
                self.kill(); return
            c = self.rect.center
            self.image = self.frames[self.index]
            self.rect = self.image.get_rect(center=c)

class AnimatedCollectible(pygame.sprite.Sprite):
    def __init__(self, x, y, frames, fps=12, bob_amp=0.0, bob_speed=1.0):
        super().__init__()
        self.frames = frames
        self.index = 0
        self.image = self.frames[self.index]
        self.rect = self.image.get_rect(center=(x, y))
        self._ft = int(1000 / max(1, fps))
        self._last = pygame.time.get_ticks()
        self._bob_amp = bob_amp
        self._bob_spd = bob_speed
        self._spawn = pygame.Vector2(self.rect.center)
        self._collected = False

    def update(self, *args):
        now = pygame.time.get_ticks()
        if now - self._last >= self._ft:
            self._last = now
            self.index = (self.index + 1) % len(self.frames)
            c = self.rect.center
            self.image = self.frames[self.index]
            self.rect = self.image.get_rect(center=c)
        if self._bob_amp:
            t = now / 1000.0
            off = math.sin(t*self._bob_spd*math.tau) * self._bob_amp
            self.rect.centery = int(self._spawn.y + off)

    def collect(self, effects_group):
        if not self._collected:
            effects_group.add(SparkleEffect(self.rect.center))
            self._collected = True
            self.kill()

def _rotate_frames(surface, n=12):
    return [pygame.transform.rotate(surface, i*(360/n)) for i in range(n)]

def _wobble_frames(surface, frames=10, span=12):
    imgs = []
    for i in range(frames):
        t = i/(frames-1) if frames>1 else 0
        tri = 1.0 - abs(2*t-1.0)
        ang = -span + 2*span*tri
        imgs.append(pygame.transform.rotate(surface, ang))
    return imgs

def _banana_surface(size=32):
    w=h=size
    surf = pygame.Surface((w,h), pygame.SRCALPHA).convert_alpha()
    cx,cy = w//2, h//2+2
    R = size*0.42
    r = R-7
    outer = [(cx + R*math.cos(math.radians(d)), cy + R*math.sin(math.radians(d))) for d in range(-50,230,6)]
    inner = [(cx + r*math.cos(math.radians(d)), cy + r*math.sin(math.radians(d))) for d in range(230,-50,-6)]
    pts = outer + inner
    pygame.draw.polygon(surf, (247,214,65), pts)
    pygame.draw.arc(surf, (220,190,50), (cx-R,cy-R,2*R,2*R), math.radians(-30), math.radians(60), 3)
    pygame.draw.arc(surf, (255,255,255,120), (cx-R,cy-R,2*R,2*R), math.radians(-10), math.radians(20), 2)
    pygame.draw.circle(surf, (120,85,20), (int(outer[0][0]), int(outer[0][1])), 2)
    pygame.draw.circle(surf, (120,85,20), (int(outer[-1][0]), int(outer[-1][1])), 2)
    return surf

class BananaPro(AnimatedCollectible):
    def __init__(self, x, y):
        base = _banana_surface(32)
        frames = _wobble_frames(base, frames=12, span=10)
        super().__init__(x, y, frames, fps=10, bob_amp=2.0, bob_speed=1.0)

def _gear_surface(size=32, teeth=8):
    w=h=size
    surf = pygame.Surface((w,h), pygame.SRCALPHA).convert_alpha()
    cx,cy = w//2,h//2
    r_out = size*0.40; r_in=size*0.28
    for i in range(teeth):
        ang = i*(math.tau/teeth)
        x1=cx+int(r_in*math.cos(ang)); y1=cy+int(r_in*math.sin(ang))
        x2=cx+int((r_out+2)*math.cos(ang)); y2=cy+int((r_out+2)*math.sin(ang))
        dx=int(3*math.cos(ang+math.pi/2)); dy=int(3*math.sin(ang+math.pi/2))
        pygame.draw.polygon(surf,(150,150,160),[(x1-dx,y1-dy),(x1+dx,y1+dy),(x2+dx,y2+dy),(x2-dx,y2-dy)])
    pygame.draw.circle(surf,(120,120,130),(cx,cy),int(r_out-2))
    pygame.draw.circle(surf,(210,210,220),(cx,cy),int(r_out-2),2)
    pygame.draw.circle(surf,(35,35,40),(cx,cy),3)
    return surf

def _prop_surface(size=32, blades=3):
    w=h=size
    surf = pygame.Surface((w,h), pygame.SRCALPHA).convert_alpha()
    cx,cy=w//2,h//2
    for i in range(blades):
        ang = i*(math.tau/blades)
        blade = pygame.Surface((w,h), pygame.SRCALPHA)
        pygame.draw.ellipse(blade,(200,200,205),(cx-4,cy-14,8,28))
        blade = pygame.transform.rotate(blade, math.degrees(ang))
        surf.blit(blade,(0,0))
    pygame.draw.circle(surf,(100,100,110),(cx,cy),4)
    pygame.draw.circle(surf,(230,230,240),(cx,cy),4,1)
    return surf

def _bolt_surface(size=28):
    w=h=size
    surf = pygame.Surface((w,h), pygame.SRCALPHA).convert_alpha()
    cx,cy=w//2,h//2
    pygame.draw.circle(surf,(180,180,190),(cx,cy),int(size*0.40))
    pygame.draw.circle(surf,(230,230,240),(cx,cy),int(size*0.40),2)
    pygame.draw.line(surf,(90,90,100),(cx-6,cy),(cx+6,cy),2)
    pygame.draw.line(surf,(90,90,100),(cx,cy-6),(cx,cy+6),2)
    return surf

class Gear(AnimatedCollectible):
    def __init__(self, x, y):
        base = _gear_surface(32, teeth=8)
        frames = _rotate_frames(base, n=12)
        super().__init__(x, y, frames, fps=12, bob_amp=1.2, bob_speed=1.2)

class PropellerPart(AnimatedCollectible):
    def __init__(self, x, y):
        base = _prop_surface(32, blades=3)
        frames = _rotate_frames(base, n=16)
        super().__init__(x, y, frames, fps=16, bob_amp=1.0, bob_speed=1.1)

class Bolt(AnimatedCollectible):
    def __init__(self, x, y):
        base = _bolt_surface(28)
        frames = _wobble_frames(base, frames=10, span=6)
        super().__init__(x, y, frames, fps=12, bob_amp=1.0, bob_speed=1.4)
