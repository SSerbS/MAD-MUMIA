
import pygame, math

class AirplanePlayer(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.base = self._draw_plane()
        self.prop = self._draw_prop()
        self.prop_angle = 0
        self.image = self.base.copy()
        self.rect = self.image.get_rect(center=pos)
        self.vel = pygame.Vector2(0,0)
        self.speed = 220

    def _draw_plane(self):
        w,h = 64, 36
        surf = pygame.Surface((w,h), pygame.SRCALPHA).convert_alpha()
        pygame.draw.ellipse(surf, (180,200,220), (4,8,56,20))
        pygame.draw.ellipse(surf, (120,170,220), (18,10,16,12))
        pygame.draw.polygon(surf, (160,180,200), [(20,18),(4,28),(30,24)])
        pygame.draw.polygon(surf, (160,180,200), [(44,18),(60,28),(34,24)])
        pygame.draw.polygon(surf, (150,170,190), [(8,18),(0,12),(8,12)])
        pygame.draw.ellipse(surf, (230,240,250), (4,8,56,20), 1)
        return surf

    def _draw_prop(self):
        w,h = 64,36
        surf = pygame.Surface((w,h), pygame.SRCALPHA).convert_alpha()
        cx,cy = 56,18
        pygame.draw.circle(surf,(100,100,110),(cx,cy),3)
        for r in range(0,360,30):
            ang = math.radians(r)
            x = cx + int(10*math.cos(ang))
            y = cy + int(10*math.sin(ang))
            pygame.draw.line(surf,(220,220,230),(cx,cy),(x,y),1)
        return surf

    def update(self, dt, keys):
        self.vel.xy = 0,0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: self.vel.x = -1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: self.vel.x = 1
        if keys[pygame.K_UP] or keys[pygame.K_w]: self.vel.y = -1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]: self.vel.y = 1
        if self.vel.length_squared() > 0:
            self.vel.scale_to_length(self.speed)
        self.rect.centerx += int(self.vel.x*dt)
        self.rect.centery += int(self.vel.y*dt)
        tilt = max(-10, min(10, -self.vel.y*0.05))
        rotated = pygame.transform.rotate(self.base, tilt)
        self.prop_angle = (self.prop_angle + 720*dt) % 360
        prop_rot = pygame.transform.rotate(self.prop, self.prop_angle)
        c = self.rect.center
        self.image = rotated.copy()
        self.image.blit(prop_rot, (0,0))
        self.rect = self.image.get_rect(center=c)

class BonecoPlayer(pygame.sprite.Sprite):
    def __init__(self, pos, color=(80,200,255)):
        super().__init__()
        self.frames = self._make_frames(color)
        self.index = 0
        self.image = self.frames[self.index]
        self.rect = self.image.get_rect(center=pos)
        self.timer = 0.0
        self.ft = 0.12
        self.vel = pygame.Vector2(0,0)
        self.speed = 160

    def _make_frames(self, color):
        frames = []
        for i in range(4):
            surf = pygame.Surface((28,38), pygame.SRCALPHA).convert_alpha()
            pygame.draw.circle(surf,(240,210,170),(14,10),8)
            pygame.draw.rect(surf,color,(6,18,16,12), border_radius=4)
            offset = (i%2)*4
            pygame.draw.rect(surf,(40,40,50),(6+offset//2,30,6,8), border_radius=2)
            pygame.draw.rect(surf,(40,40,50),(16-offset//2,30,6,8), border_radius=2)
            pygame.draw.circle(surf,(0,0,0),(11,9),1)
            pygame.draw.circle(surf,(0,0,0),(17,9),1)
            frames.append(surf)
        return frames

    def update(self, dt, keys):
        self.vel.xy = 0,0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: self.vel.x = -1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: self.vel.x = 1
        if keys[pygame.K_UP] or keys[pygame.K_w]: self.vel.y = -1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]: self.vel.y = 1
        if self.vel.length_squared() > 0:
            self.vel.scale_to_length(self.speed)
        self.rect.centerx += int(self.vel.x*dt)
        self.rect.centery += int(self.vel.y*dt)
        moving = self.vel.length_squared() > 0
        self.timer += dt
        if moving and self.timer >= self.ft:
            self.timer = 0.0
            self.index = (self.index+1) % len(self.frames)
            c = self.rect.center
            self.image = self.frames[self.index]
            self.rect = self.image.get_rect(center=c)
        elif not moving:
            self.index = 0
            c = self.rect.center
            self.image = self.frames[self.index]
            self.rect = self.image.get_rect(center=c)
