import pygame
import random

class Coletavel(pygame.sprite.Sprite):
    def __init__(self, tipo, x, y):
        super().__init__()
        self.tipo = tipo
        self.image = self.gerar_imagem(tipo)
        self.rect = self.image.get_rect(center=(x, y))

    def gerar_imagem(self, tipo):
        surf = pygame.Surface((32, 32), pygame.SRCALPHA)
        if tipo == "banana":
            pygame.draw.ellipse(surf, (255, 255, 0), (2, 8, 28, 16))
            pygame.draw.polygon(surf, (139, 69, 19), [(15, 8), (17, 2), (19, 8)])
        elif tipo == "peca":
            pygame.draw.polygon(surf, (192, 192, 192), [(16, 0), (32, 8), (26, 32), (6, 32), (0, 8)])
            pygame.draw.circle(surf, (105, 105, 105), (16, 16), 5)
        elif tipo == "municao":
            pygame.draw.rect(surf, (255, 0, 0), (10, 0, 12, 20))
            pygame.draw.rect(surf, (255, 255, 0), (10, 20, 12, 8))
        return surf

    def update(self):
        pass
