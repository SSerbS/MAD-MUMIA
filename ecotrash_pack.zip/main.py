import pygame
import random
from coletaveis import Coletavel
from efeitos import Faisca

pygame.init()
tela = pygame.display.set_mode((800, 600))
pygame.display.set_caption("EcoTrash com Faísca + HUD")
clock = pygame.time.Clock()

todos = pygame.sprite.Group()
itens = pygame.sprite.Group()
efeitos = pygame.sprite.Group()

player = pygame.sprite.Sprite()
player.image = pygame.Surface((40, 40))
player.image.fill((0, 0, 255))
player.rect = player.image.get_rect(center=(400, 300))
todos.add(player)

vida = 3
municao = 0
pecas = 0
bananas = 0

def spawn_itens():
    tipos = ["banana", "peca", "municao"]
    for _ in range(10):
        tipo = random.choice(tipos)
        x = random.randint(50, 750)
        y = random.randint(50, 550)
        item = Coletavel(tipo, x, y)
        itens.add(item)
        todos.add(item)

spawn_itens()

rodando = True
while rodando:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            rodando = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        player.rect.x -= 5
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        player.rect.x += 5
    if keys[pygame.K_UP] or keys[pygame.K_w]:
        player.rect.y -= 5
    if keys[pygame.K_DOWN] or keys[pygame.K_s]:
        player.rect.y += 5

    colididos = pygame.sprite.spritecollide(player, itens, True)
    for item in colididos:
        if item.tipo == "banana":
            bananas += 1
        elif item.tipo == "peca":
            pecas += 1
        elif item.tipo == "municao":
            municao += 5
        fa = Faisca(item.rect.centerx, item.rect.centery)
        efeitos.add(fa)
        todos.add(fa)

    todos.update()

    tela.fill((30, 30, 30))
    todos.draw(tela)

    fonte = pygame.font.SysFont(None, 30)
    hud_text = f"Vida: {vida} | Munição: {municao} | Peças: {pecas} | Bananas: {bananas}"
    hud_img = fonte.render(hud_text, True, (255, 255, 255))
    tela.blit(hud_img, (10, 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
