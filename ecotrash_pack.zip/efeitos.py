import pygame
import random

class Faisca(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = []
        for _ in range(5):
            surf = pygame.Surface((20, 20), pygame.SRCALPHA)
            for _ in range(5):
                px = random.randint(0, 20)
                py = random.randint(0, 20)
                pygame.draw.circle(surf, (255, 255, 0), (px, py), 1)
            self.frames.append(surf)
        self.index = 0
        self.image = self.frames[self.index]
        self.rect = self.image.get_rect(center=(x, y))
        self.timer = 0

    def update(self):
        self.timer += 1
        if self.timer % 5 == 0:
            self.index += 1
            if self.index < len(self.frames):
                self.image = self.frames[self.index]
            else:
                self.kill()
